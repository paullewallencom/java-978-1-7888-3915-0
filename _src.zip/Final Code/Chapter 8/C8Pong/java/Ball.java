package com.gamecodeschool.c8pong;

class Ball {
}