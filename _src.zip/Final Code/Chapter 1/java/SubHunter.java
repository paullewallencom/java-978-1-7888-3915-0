package com.gamecodeschool.subhunter;

import android.app.Activity;
import android.os.Bundle;

public class SubHunter extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}




