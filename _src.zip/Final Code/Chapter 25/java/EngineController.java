package com.gamecodeschool.c25platformer;

interface EngineController {
    // This allows the GameState class to start a new level
    void startNewLevel();
}
