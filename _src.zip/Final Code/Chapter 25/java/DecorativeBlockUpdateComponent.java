package com.gamecodeschool.c25platformer;

class DecorativeBlockUpdateComponent implements UpdateComponent {
    @Override
    public void update(long fps, Transform t, Transform playerTransform) {
        // Do nothing
        // Not even set a collider
    }
}
