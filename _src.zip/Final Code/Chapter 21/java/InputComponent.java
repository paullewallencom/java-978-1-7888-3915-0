package com.gamecodeschool.c21scrollingshooter;

interface InputComponent {

    void setTransform(Transform t);
}
