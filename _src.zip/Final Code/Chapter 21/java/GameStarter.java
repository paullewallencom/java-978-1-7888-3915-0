package com.gamecodeschool.c21scrollingshooter;

interface GameStarter {
    // This allows the State class to
    // spawn and despawn objects via the game engine
    public void deSpawnReSpawn();
}
