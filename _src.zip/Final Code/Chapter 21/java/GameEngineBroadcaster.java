package com.gamecodeschool.c21scrollingshooter;

interface GameEngineBroadcaster {

    void addObserver(InputObserver o);
}
