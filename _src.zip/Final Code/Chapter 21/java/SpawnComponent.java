package com.gamecodeschool.c21scrollingshooter;

interface SpawnComponent {

    void spawn(Transform playerTransform,
               Transform t);
}
