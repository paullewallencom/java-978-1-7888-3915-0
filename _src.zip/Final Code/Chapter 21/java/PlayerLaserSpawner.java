package com.gamecodeschool.c21scrollingshooter;

public interface PlayerLaserSpawner {
        boolean spawnPlayerLaser(Transform transform);
}
