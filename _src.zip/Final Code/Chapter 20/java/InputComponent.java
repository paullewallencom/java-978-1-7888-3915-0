package com.gamecodeschool.c20scrollingshooter;

interface InputComponent {

    void setTransform(Transform t);
}
