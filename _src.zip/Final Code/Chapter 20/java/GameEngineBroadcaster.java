package com.gamecodeschool.c20scrollingshooter;

interface GameEngineBroadcaster {

    void addObserver(InputObserver o);
}
