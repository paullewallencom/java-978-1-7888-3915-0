package com.gamecodeschool.c20scrollingshooter;

interface SpawnComponent {

    void spawn(Transform playerTransform,
               Transform t);
}
