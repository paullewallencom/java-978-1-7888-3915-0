package com.gamecodeschool.c20scrollingshooter;

public interface PlayerLaserSpawner {
        boolean spawnPlayerLaser(Transform transform);
}
