package com.gamecodeschool.c12bullethell;

class Bob {
}
