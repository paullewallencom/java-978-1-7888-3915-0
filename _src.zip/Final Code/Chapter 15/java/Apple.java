package com.gamecodeschool.c15snake;

/**
 * Created by johnh on 22/12/2017.
 */

class Apple {
}
