package com.gamecodeschool.c16snake;

/**
 * Created by johnh on 22/12/2017.
 */

class Snake {
}
