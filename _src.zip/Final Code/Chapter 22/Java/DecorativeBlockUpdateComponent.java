package com.gamecodeschool.c22platformer;

class DecorativeBlockUpdateComponent implements UpdateComponent {
    @Override
    public void update(long fps, Transform t, Transform playerTransform) {
        // Do nothing
        // Not even set a collider
    }
}
