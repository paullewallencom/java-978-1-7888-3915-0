package com.gamecodeschool.c22platformer;

interface EngineController {
    // This allows the GameState class to start a new level
    void startNewLevel();
}
