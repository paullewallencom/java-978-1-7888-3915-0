package com.gamecodeschool.c9pong;

class Ball {
}
