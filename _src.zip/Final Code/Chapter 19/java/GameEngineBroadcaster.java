package com.gamecodeschool.c19scrollingshooter;

interface GameEngineBroadcaster {

    void addObserver(InputObserver o);
}
