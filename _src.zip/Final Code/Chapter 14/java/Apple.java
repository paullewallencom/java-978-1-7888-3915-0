package com.gamecodeschool.c14snake;

/**
 * Created by johnh on 22/12/2017.
 */

class Apple {
}
